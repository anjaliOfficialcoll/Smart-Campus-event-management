package com.campus.events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Smart Campus Event Management System
 * Entry point for the Spring Boot application.
 *
 * Run this class to start the server on http://localhost:8080
 *
 * Default Admin Credentials:
 *   Username: admin
 *   Password: admin123
 */
@SpringBootApplication
public class SmartCampusApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCampusApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("  Smart Campus Events App is running!");
        System.out.println("  URL: http://localhost:8080");
        System.out.println("  Admin Login: http://localhost:8080/admin/login");
        System.out.println("  H2 Console: http://localhost:8080/h2-console");
        System.out.println("========================================\n");
    }
}
