package com.campus.events.config;

import com.campus.events.entity.*;
import com.campus.events.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * DataInitializer - Seeds the database with sample data on application startup.
 * Implements CommandLineRunner so it runs after the Spring context is ready.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired private EventRepository eventRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private RegistrationRepository registrationRepository;
    @Autowired private FeedbackRepository feedbackRepository;

    @Override
    public void run(String... args) throws Exception {
        if (eventRepository.count() > 0) return; // Don't seed if data already exists

        System.out.println(">>> Seeding sample data...");

        // ── Create Sample Events ───────────────────────────────────────────────

        Event e1 = new Event();
        e1.setName("AI & Machine Learning Workshop");
        e1.setDescription("Hands-on workshop covering neural networks, deep learning frameworks like TensorFlow and PyTorch, and real-world ML project building. Perfect for CS students looking to enter the AI field.");
        e1.setDate(LocalDate.now().plusDays(5));
        e1.setTime(LocalTime.of(10, 0));
        e1.setVenue("CS Lab Block A, Room 204");
        e1.setDepartment("Computer Science");
        e1.setEventType("WORKSHOP");
        e1.setCapacity(60);

        Event e2 = new Event();
        e2.setName("National Science Symposium");
        e2.setDescription("Annual science symposium where students present research papers in physics, chemistry, and biology. Distinguished faculty from IITs will judge the presentations. Cash prizes for top 3 teams.");
        e2.setDate(LocalDate.now().plusDays(10));
        e2.setTime(LocalTime.of(9, 30));
        e2.setVenue("Main Auditorium");
        e2.setDepartment("Science");
        e2.setEventType("SEMINAR");
        e2.setCapacity(200);

        Event e3 = new Event();
        e3.setName("Fresher's Cultural Night");
        e3.setDescription("Welcome event for first-year students featuring live music, dance performances, stand-up comedy, and talent showcase. Come and make new friends!");
        e3.setDate(LocalDate.now().plusDays(3));
        e3.setTime(LocalTime.of(18, 0));
        e3.setVenue("Open Air Theatre");
        e3.setDepartment("All Departments");
        e3.setEventType("CULTURAL");
        e3.setCapacity(500);

        Event e4 = new Event();
        e4.setName("Inter-College Cricket Tournament");
        e4.setDescription("Two-day cricket tournament with 8 college teams competing. Registration open for teams of 11 + 4 substitutes. Trophy and cash prize for winners. Lunch provided for participants.");
        e4.setDate(LocalDate.now().plusDays(14));
        e4.setTime(LocalTime.of(8, 0));
        e4.setVenue("Sports Ground");
        e4.setDepartment("Sports");
        e4.setEventType("SPORTS");
        e4.setCapacity(150);

        Event e5 = new Event();
        e5.setName("Full Stack Web Development Bootcamp");
        e5.setDescription("Intensive 2-day bootcamp on modern web development. Topics include React, Node.js, REST APIs, and cloud deployment. Participants will build and deploy a full project by the end.");
        e5.setDate(LocalDate.now().plusDays(7));
        e5.setTime(LocalTime.of(9, 0));
        e5.setVenue("IT Department Seminar Hall");
        e5.setDepartment("Information Technology");
        e5.setEventType("WORKSHOP");
        e5.setCapacity(80);

        Event e6 = new Event();
        e6.setName("Entrepreneurship & Startup Talk");
        e6.setDescription("Inspiring talk by successful startup founders from Chennai. Topics include ideation, funding, MVP development, and scaling. Q&A session and networking dinner included.");
        e6.setDate(LocalDate.now().plusDays(12));
        e6.setTime(LocalTime.of(14, 0));
        e6.setVenue("MBA Block Seminar Hall");
        e6.setDepartment("Management");
        e6.setEventType("SEMINAR");
        e6.setCapacity(120);

        Event e7 = new Event();
        e7.setName("Robotics & IoT Expo");
        e7.setDescription("Exhibition of student-built robots and IoT projects. Showcasing autonomous navigation, smart home automation, drone tech, and more. Open to all departments.");
        e7.setDate(LocalDate.now().plusDays(20));
        e7.setTime(LocalTime.of(10, 0));
        e7.setVenue("Engineering Block Foyer");
        e7.setDepartment("Electronics & Communication");
        e7.setEventType("TECHNICAL");
        e7.setCapacity(300);

        Event e8 = new Event();
        e8.setName("Mental Health Awareness Seminar");
        e8.setDescription("Seminar on student mental health with certified counsellors. Topics: managing exam stress, mindfulness techniques, building resilience. Free counselling sessions available post-event.");
        e8.setDate(LocalDate.now().plusDays(8));
        e8.setTime(LocalTime.of(11, 0));
        e8.setVenue("Psychology Dept. Auditorium");
        e8.setDepartment("Psychology");
        e8.setEventType("SEMINAR");
        e8.setCapacity(100);

        eventRepository.save(e1);
        eventRepository.save(e2);
        eventRepository.save(e3);
        eventRepository.save(e4);
        eventRepository.save(e5);
        eventRepository.save(e6);
        eventRepository.save(e7);
        eventRepository.save(e8);

        // ── Create Sample Students ─────────────────────────────────────────────

        Student s1 = new Student();
        s1.setName("Arjun Ramesh");
        s1.setEmail("arjun.ramesh@student.edu");
        s1.setStudentId("CS2021001");
        s1.setDepartment("Computer Science");
        s1.setPhone("9876543210");

        Student s2 = new Student();
        s2.setName("Priya Nair");
        s2.setEmail("priya.nair@student.edu");
        s2.setStudentId("IT2022045");
        s2.setDepartment("Information Technology");
        s2.setPhone("9765432109");

        studentRepository.save(s1);
        studentRepository.save(s2);

        // ── Create Sample Registrations ────────────────────────────────────────

        Registration r1 = new Registration();
        r1.setStudent(s1);
        r1.setEvent(e1);
        registrationRepository.save(r1);

        Registration r2 = new Registration();
        r2.setStudent(s1);
        r2.setEvent(e3);
        registrationRepository.save(r2);

        Registration r3 = new Registration();
        r3.setStudent(s2);
        r3.setEvent(e5);
        registrationRepository.save(r3);

        Registration r4 = new Registration();
        r4.setStudent(s2);
        r4.setEvent(e3);
        registrationRepository.save(r4);

        // ── Create Sample Feedback ─────────────────────────────────────────────

        Feedback f1 = new Feedback();
        f1.setStudent(s1);
        f1.setEvent(e1);
        f1.setComments("Excellent workshop! The hands-on sessions were very helpful. I learned a lot about neural networks and was able to build my first ML model.");
        f1.setRating(5);
        feedbackRepository.save(f1);

        Feedback f2 = new Feedback();
        f2.setStudent(s2);
        f2.setEvent(e5);
        f2.setComments("Well organized bootcamp. The instructors were knowledgeable. Would have liked more time for the deployment section.");
        f2.setRating(4);
        feedbackRepository.save(f2);

        System.out.println(">>> Sample data seeded successfully! 8 events, 2 students, 4 registrations, 2 feedbacks.");
    }
}
