package com.campus.events.exception;

/**
 * Thrown when a requested resource (Event, Student, Registration) is not found in the DB.
 */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
